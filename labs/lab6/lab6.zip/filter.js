if (document.getElementById("di0_27945") != null) {
    document.getElementById("di0_27945").innerHTML = 0.75;
}

if (document.getElementById("di0_27930") != null) {
    document.getElementById("di0_27930").innerHTML = 0.25;
}

if (document.getElementById("di0_27931") != null) {
    document.getElementById("di0_27931").innerHTML = 0;
    document.getElementById("di0_27931").parentNode.style.color="red";
}

if (document.getElementById("di0_27941") != null) {
    document.getElementById("di0_27941").innerHTML = 0.25;
}

if (document.getElementById("di0_27926") != null) {
    document.getElementById("di0_27926").innerHTML = 0.5;
}

if (document.getElementById("di0_27943") != null) {
    document.getElementById("di0_27943").innerHTML = 0.75;
}

if (document.getElementById("di0_27933") != null) {
    document.getElementById("di0_27933").innerHTML = 0.25;
}

if (document.getElementById("di0_27944") != null) {
    document.getElementById("di0_27944").innerHTML = 0.25;
}

if (document.getElementById("di0_27927") != null) {
    document.getElementById("di0_27927").innerHTML = 0.75;
}

if (document.getElementById("di0_27928") != null) {
    document.getElementById("di0_27928").innerHTML = 0.5;
}

if (document.getElementById("di0_27947") != null) {
    document.getElementById("di0_27947").innerHTML = 0.25;
}

if (document.getElementById("di0_27953") != null) {
    document.getElementById("di0_27953").innerHTML = 0;
    document.getElementById("di0_27953").parentNode.style.color="red";
}

if (document.getElementById("di0_27962") != null) {
    document.getElementById("di0_27962").innerHTML = 0;
    document.getElementById("di0_27962").parentNode.style.color="red";
}

if (document.getElementById("di0_27948") != null) {
    document.getElementById("di0_27948").innerHTML = 0.25;
}

if (document.getElementById("di0_27965") != null) {
    document.getElementById("di0_27965").innerHTML = 0.25;
}

if (document.getElementById("di0_27963") != null) {
    document.getElementById("di0_27963").innerHTML = 0.5;
}

if (document.getElementById("di0_27949") != null) {
    document.getElementById("di0_27949").innerHTML = 0.25;
}

if (document.getElementById("di0_27958") != null) {
    document.getElementById("di0_27958").innerHTML = 0.25;
}

if (document.getElementById("di0_27966") != null) {
    document.getElementById("di0_27966").innerHTML = 0.25;
}

if (document.getElementById("di0_27959") != null) {
    document.getElementById("di0_27959").innerHTML = 0.75;
}

if (document.getElementById("di0_27997") != null) {
    document.getElementById("di0_27997").innerHTML = 0;
    document.getElementById("di0_27997").parentNode.style.color="red";
}

if (document.getElementById("di0_27984") != null) {
    document.getElementById("di0_27984").innerHTML = 0.75;
}

if (document.getElementById("di0_27998") != null) {
    document.getElementById("di0_27998").innerHTML = 0.25;
}

if (document.getElementById("di0_27985") != null) {
    document.getElementById("di0_27985").innerHTML = 0.25;
}

if (document.getElementById("di0_27993") != null) {
    document.getElementById("di0_27993").innerHTML = 0.5;
}

if (document.getElementById("di0_27989") != null) {
    document.getElementById("di0_27989").innerHTML = 0.25;
}

if (document.getElementById("di0_27980") != null) {
    document.getElementById("di0_27980").innerHTML = 0;
    document.getElementById("di0_27980").parentNode.style.color="red";
}

if (document.getElementById("di0_27995") != null) {
    document.getElementById("di0_27995").innerHTML = 0.25;
}

if (document.getElementById("di0_27992") != null) {
    document.getElementById("di0_27992").innerHTML = 0.5;
}

if (document.getElementById("di0_28000") != null) {
    document.getElementById("di0_28000").innerHTML = 0;
    document.getElementById("di0_28000").parentNode.style.color="red";
}

if (document.getElementById("di0_27994") != null) {
    document.getElementById("di0_27994").innerHTML = 0;
    document.getElementById("di0_27994").parentNode.style.color="red";
}

if (document.getElementById("di0_28001") != null) {
    document.getElementById("di0_28001").innerHTML = 0.25;
}

if (document.getElementById("di0_27990") != null) {
    document.getElementById("di0_27990").innerHTML = -0.25;
    document.getElementById("di0_27990").parentNode.style.color="red";
}

if (document.getElementById("di0_27987") != null) {
    document.getElementById("di0_27987").innerHTML = 0.25;
}

if (document.getElementById("di0_27996") != null) {
    document.getElementById("di0_27996").innerHTML = 0.25;
}